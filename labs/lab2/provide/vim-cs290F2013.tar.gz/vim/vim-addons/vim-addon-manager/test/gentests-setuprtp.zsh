#!/bin/zsh
emulate -L zsh
cd ../rtp
tar -xJf ../test/runtime.tar.xz
rm ../test/runtime.tar.xz
